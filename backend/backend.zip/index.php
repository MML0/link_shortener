<?php
require "db.php";

$route = $_GET['route'] ?? null;

// No route → redirect to home
if (!$route) {
    header("Location: https://banoo.khas.shop");
    exit;
}

// Find short link
$stmt = $pdo->prepare("SELECT * FROM links WHERE short_code = ?");
$stmt->execute([$route]);
$link = $stmt->fetch();

if ($link) {
    // Increase hit counter
    $pdo->prepare("UPDATE links SET hits = hits + 1 WHERE id = ?")
        ->execute([$link['id']]);

    header("Location: " . $link['long_url']);
    exit;
}

// Not found
http_response_code(404);
echo "404 - Page not found";
